/*
 * General helper functions
 */

export default class ThemeUtilities {
  constructor() {}
};
