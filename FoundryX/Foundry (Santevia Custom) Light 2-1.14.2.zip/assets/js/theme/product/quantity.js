export default function (window) {

}
