import PageManager from '../PageManager';

export default class Account extends PageManager {
  constructor() {
    super();
  }
}
