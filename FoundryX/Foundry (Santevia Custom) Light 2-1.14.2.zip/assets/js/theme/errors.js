import PageManager from '../PageManager';

export default class Errors extends PageManager {
    constructor() {
        super();
    }
}
